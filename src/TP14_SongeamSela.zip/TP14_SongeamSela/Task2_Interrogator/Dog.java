package TP14_SongeamSela.Task2_Interrogator;

public class Dog extends Animal {
    @Override
    public void talk() {
        System.out.println("Wolf Wolf!");
    }
}
