package TP14_SongeamSela.Task2_Interrogator;

public class Cat extends Animal {
    @Override
    public void talk() {
        System.out.println("Moew Moew!!");
    }
}
