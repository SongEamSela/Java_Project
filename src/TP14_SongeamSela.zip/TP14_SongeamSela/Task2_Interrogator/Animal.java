package TP14_SongeamSela.Task2_Interrogator;

public abstract class Animal
implements Talkative{
    public abstract void talk();
}
