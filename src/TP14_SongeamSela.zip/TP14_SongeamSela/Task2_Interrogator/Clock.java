package TP14_SongeamSela.Task2_Interrogator;

public class Clock {
    //...
}
