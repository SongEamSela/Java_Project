package TP14_SongeamSela.Task2_Interrogator;

public class Bird extends Animal {
    @Override
    public void talk() {
        System.out.println("Chib Chib!!");
    }
}
