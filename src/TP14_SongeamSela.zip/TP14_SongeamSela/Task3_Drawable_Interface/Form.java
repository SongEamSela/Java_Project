package TP14_SongeamSela.Task3_Drawable_Interface;

public class Form {
    double x,y;
    double Surface(){
        return 0;
    }
    double perimeter(){
        return 0;
    }
    void  move(double dx,double dy){
        x +=dx;
        y+=dy;
    }

}
