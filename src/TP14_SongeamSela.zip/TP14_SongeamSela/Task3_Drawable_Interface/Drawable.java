package TP14_SongeamSela.Task3_Drawable_Interface;

import java.awt.*;

public interface Drawable {
    void draw(Graphics g);
    void erase(Graphics g);
}
