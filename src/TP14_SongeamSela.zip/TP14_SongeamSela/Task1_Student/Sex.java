package TP14_SongeamSela.Task1_Student;

public enum  Sex {
    Male, Female
}
